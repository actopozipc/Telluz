﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class Landesstatistik
    {
        public string country { get; set; }
       public List<KategorieMitJahrenUndWerten> ListeMitKategorienMitJahrenUndWerten { get; set; }
     
  
   
    }
}
