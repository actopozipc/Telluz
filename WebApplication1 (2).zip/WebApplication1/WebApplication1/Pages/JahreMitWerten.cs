﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class JahrMitWert
    {
        public int year { get; set; }
        public decimal value { get; set; }
        public JahrMitWert()
        {

        }
        public JahrMitWert(int y, decimal v)
        {
            year = y;
            value = v;
        }
    }
}
