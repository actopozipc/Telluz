﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class KategorieMitJahrenUndWerten
    {
        public string description { get; set; }
        public List<JahrMitWert> JahreMitWerten { get; set; }
      public KategorieMitJahrenUndWerten(string d, List<JahrMitWert> J)
        {
            description = d;
            JahreMitWerten = J;
        }
        public KategorieMitJahrenUndWerten()
        {

        }
    }
   
}
