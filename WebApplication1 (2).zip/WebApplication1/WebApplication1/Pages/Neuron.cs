﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class Neuron
    {
         public double[] inputs = new double[2];
        public double[] weights = new double[2];
        public double error;
        int multiplikator;
        private double biasWeight;

        private Random r = new Random();
        public Neuron()
        {

        }
        public Neuron(int m)
        {
            multiplikator = m;
        }
        public double output
        {
            // get { return sigmoid.output(weights[0] * inputs[0] + weights[1] * inputs[1] + biasWeight); }
            get { return sigmoid.output(weights[0] * inputs[0] + biasWeight); }
        }

        public void randomizeWeights()
        {
            weights[0] = r.NextDouble();
            biasWeight = r.NextDouble();
        }

        public void adjustWeights()
        {
            weights[0] += error * inputs[0];
            biasWeight += error;
        }
    }
}
