﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class sigmoid
    {
        public static double output(double x)
        {
            double temp = 1 / (1 + Math.Exp(-x));

            return temp;

        }

        public static double derivative(double x)
        {
            return x * (1.0 - x);
        }
    }
}
